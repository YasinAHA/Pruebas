// src/features/auth/index.ts
export { default as LoginPage } from './pages/LoginPage'
