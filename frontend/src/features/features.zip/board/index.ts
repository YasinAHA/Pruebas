export { default as DashboardPage } from './pages/DashboardPage'
